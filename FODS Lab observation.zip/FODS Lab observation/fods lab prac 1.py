
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

age = [23,23,27,27,39,41,41,47,49,
       50,52,54,54,56,57,58,58,60]

fat = [9.5,26.5,7.8,17.8,31.4,25.9,
       25.9,27.4,27.2,31.2,34.6,42.5,
       28.8,33.4,30.2,34.1,32.9,41.2]

df = pd.DataFrame({'Age': age, '%Fat': fat})

print(df.describe())

df.boxplot()
plt.show()

plt.scatter(age, fat)
plt.xlabel("Age")
plt.ylabel("Body Fat")
plt.show()

plt.subplot(1,2,1)
stats.probplot(age, dist="norm", plot=plt)

plt.subplot(1,2,2)
stats.probplot(fat, dist="norm", plot=plt)

plt.tight_layout()
plt.show()
