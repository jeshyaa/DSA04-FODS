import pandas as pd
import re
import matplotlib.pyplot as plt
from collections import Counter
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

df = pd.read_csv("data.csv")
text = " ".join(df["feedback"].dropna()).lower()
text = re.sub(r'[^a-z\s]', '', text)

words = [w for w in text.split()
         if w not in ENGLISH_STOP_WORDS]

freq = Counter(words)
n = int(input("Enter N: "))

top = freq.most_common(n)
print(top)

plt.bar([x[0] for x in top], [x[1] for x in top])
plt.xlabel("Words")
plt.ylabel("Frequency")
plt.title("Top N Words")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
