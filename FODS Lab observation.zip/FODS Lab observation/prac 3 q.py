
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.DataFrame({
    'Study Time': [1,2,2.5,3,4,4.5,5,6,6.5,7,8,9],
    'Exam Score': [35,40,45,50,55,58,62,70,72,78,85,92]
})

r = df['Study Time'].corr(df['Exam Score'])
print("Correlation:", round(r, 4))

plt.scatter(df['Study Time'], df['Exam Score'])
plt.xlabel("Study Time")
plt.ylabel("Exam Score")
plt.show()

sns.regplot(x='Study Time', y='Exam Score', data=df)
plt.show()
