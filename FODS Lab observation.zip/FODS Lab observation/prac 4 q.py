
import pandas as pd

df = pd.DataFrame({
    'Chennai': [25,26,28,31,33,33,31,30,30,28,26,25],
    'Delhi': [14,17,23,29,34,35,32,31,30,25,19,15],
    'Shimla': [4,5,10,15,19,21,19,18,16,12,8,5],
    'Mumbai': [24,25,27,29,31,30,28,28,28,29,28,26]
})

print("Mean:\n", df.mean())
print("Standard Deviation:\n", df.std())

ranges = df.max() - df.min()
print("Temperature Range:\n", ranges)

print("Highest Range:", ranges.idxmax())
print("Most Consistent:", df.std().idxmin())
