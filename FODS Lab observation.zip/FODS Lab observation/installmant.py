pip install pandas matplotlib scikit-learn
